#ifndef DIAGRAMS_B_H
#define DIAGRAMS_B_H
class A;
class B { public: A *m_a; };
#endif
