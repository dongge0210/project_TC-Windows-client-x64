var searchData=
[
  ['markdown_20support_0',['Markdown support',['../markdown.html',1,'']]],
  ['module_20output_1',['Perl Module Output',['../perlmod.html',1,'']]]
];
