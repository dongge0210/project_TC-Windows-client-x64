var searchData=
[
  ['4_0',['4',['../changelog.html#log_1_8_4',1,'Release 1.8.4'],['../changelog.html#log_1_9_4',1,'Release 1.9.4']]],
  ['4_20series_1',['1.4 Series',['../changelog.html#log_1_4',1,'']]]
];
