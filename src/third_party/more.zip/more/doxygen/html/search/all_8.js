var searchData=
[
  ['7_0',['7',['../changelog.html#log_1_8_7',1,'Release 1.8.7'],['../changelog.html#log_1_9_7',1,'Release 1.9.7']]],
  ['7_20series_1',['1.7 Series',['../changelog.html#log_1_7',1,'']]]
];
