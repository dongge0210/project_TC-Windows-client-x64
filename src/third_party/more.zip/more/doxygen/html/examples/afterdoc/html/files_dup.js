var files_dup =
[
    [ "afterdoc.h", "afterdoc_8h_source.html", null ]
];