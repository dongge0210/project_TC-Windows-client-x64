var manual_8c =
[
    [ "Object", "struct_object.html", "struct_object" ],
    [ "Vehicle", "struct_vehicle.html", "struct_vehicle" ],
    [ "Car", "struct_car.html", "struct_car" ],
    [ "Truck", "struct_truck.html", "struct_truck" ],
    [ "main", "manual_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ]
];