var annotated_dup =
[
    [ "Car", "struct_car.html", "struct_car" ],
    [ "Object", "struct_object.html", "struct_object" ],
    [ "Truck", "struct_truck.html", "struct_truck" ],
    [ "Vehicle", "struct_vehicle.html", "struct_vehicle" ]
];