var struct_vehicle =
[
    [ "vehicleStart", "struct_vehicle.html#a6891d3d28853bc3fdd075596dc6de9f8", null ],
    [ "vehicleStop", "struct_vehicle.html#a4dcbcba43792dcd673a552b14479ab77", null ],
    [ "base", "struct_vehicle.html#ad7970f528d429f6fc1725173e93a77c2", null ]
];