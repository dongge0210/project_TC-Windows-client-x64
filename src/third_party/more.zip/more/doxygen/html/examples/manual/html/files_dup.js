var files_dup =
[
    [ "manual.c", "manual_8c.html", "manual_8c" ]
];