var hierarchy =
[
    [ "Object", "struct_object.html", [
      [ "Vehicle", "struct_vehicle.html", [
        [ "Car", "struct_car.html", null ],
        [ "Truck", "struct_truck.html", null ]
      ] ]
    ] ]
];