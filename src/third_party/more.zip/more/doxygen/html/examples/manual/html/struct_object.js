var struct_object =
[
    [ "objRef", "struct_object.html#a71225073d06a793b9a6ea9263ed37b12", null ],
    [ "objUnref", "struct_object.html#a924ee0cecc906d148022b3f0d6325cfb", null ],
    [ "ref", "struct_object.html#a1b6037fba835e83243ababce426ff9af", null ]
];