var structcmd_8h =
[
    [ "MAX", "structcmd_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "UINT32", "structcmd_8h.html#ae1e6edbbc26d6fbc71a90190d0266018", null ],
    [ "close", "structcmd_8h.html#ae152484c890a24e4d9b4980e7b965be0", null ],
    [ "open", "structcmd_8h.html#a2c4414339f388561554c2deab11a1a07", null ],
    [ "read", "structcmd_8h.html#a9c7b76d5266903891c803132d51ccb90", null ],
    [ "write", "structcmd_8h.html#af2a3ea719b83f672637febdd87c36c36", null ],
    [ "errno", "structcmd_8h.html#ad65a8842cc674e3ddf69355898c0ecbf", null ]
];