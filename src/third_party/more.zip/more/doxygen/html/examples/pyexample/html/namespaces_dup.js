var namespaces_dup =
[
    [ "pyexample", "namespacepyexample.html", "namespacepyexample" ]
];