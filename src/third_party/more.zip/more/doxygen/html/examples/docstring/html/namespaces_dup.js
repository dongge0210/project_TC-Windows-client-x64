var namespaces_dup =
[
    [ "docstring", "namespacedocstring.html", "namespacedocstring" ]
];