var docstring_8py =
[
    [ "docstring.PyClass", "classdocstring_1_1_py_class.html", "classdocstring_1_1_py_class" ],
    [ "docstring.func", "namespacedocstring.html#a6f9fd32331615ace36a6fa454a197ba2", null ]
];