var annotated_dup =
[
    [ "docstring", "namespacedocstring.html", [
      [ "PyClass", "classdocstring_1_1_py_class.html", "classdocstring_1_1_py_class" ]
    ] ]
];