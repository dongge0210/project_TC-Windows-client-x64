var memgrp_8cpp =
[
    [ "Memgrp_Test", "class_memgrp___test.html", "class_memgrp___test" ],
    [ "A", "memgrp_8cpp.html#a955f504eccf76b4eb2489c0adab03121", null ],
    [ "B", "memgrp_8cpp.html#a111da81ae5883147168bbb8366377b10", null ],
    [ "glob_func", "memgrp_8cpp.html#a36cb413747454fcdba9dd7b8f972fcf3", null ]
];