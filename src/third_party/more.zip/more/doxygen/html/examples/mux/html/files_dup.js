var files_dup =
[
    [ "mux.vhdl", "mux_8vhdl.html", "mux_8vhdl" ]
];