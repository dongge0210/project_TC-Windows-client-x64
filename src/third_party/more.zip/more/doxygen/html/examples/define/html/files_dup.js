var files_dup =
[
    [ "define.h", "define_8h.html", "define_8h" ]
];