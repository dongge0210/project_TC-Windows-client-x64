var files_dup =
[
    [ "javadoc-banner.h", "javadoc-banner_8h.html", "javadoc-banner_8h" ]
];