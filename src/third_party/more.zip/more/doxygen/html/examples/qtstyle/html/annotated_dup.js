var annotated_dup =
[
    [ "QTstyle_Test", "class_q_tstyle___test.html", "class_q_tstyle___test" ]
];