var annotated_dup =
[
    [ "SomeNiceClass", "class_some_nice_class.html", null ]
];