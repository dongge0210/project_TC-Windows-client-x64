var NAVTREEINDEX0 =
{
"annotated.html":[1,0],
"bug.html":[0],
"class_some_nice_class.html":[1,0,0],
"classes.html":[1,1],
"index.html":[],
"pages.html":[]
};
