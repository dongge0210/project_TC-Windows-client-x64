var NAVTREEINDEX0 =
{
"index.html":[],
"page1.html":[0],
"page1.html#sec":[0,0],
"page1.html#subsection1":[0,0,0],
"page1.html#subsection2":[0,0,1],
"page2.html":[1],
"pages.html":[]
};
