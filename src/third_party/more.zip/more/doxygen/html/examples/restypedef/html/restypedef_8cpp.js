var restypedef_8cpp =
[
    [ "CoordStruct", "struct_coord_struct.html", "struct_coord_struct" ],
    [ "Coord", "restypedef_8cpp.html#a013489fb99c6a5b012db8ec66544a507", null ],
    [ "add", "restypedef_8cpp.html#a102acaaa258e937adf910898c6133545", null ]
];