var struct_coord_struct =
[
    [ "x", "struct_coord_struct.html#a183d7226fc5a8470ce9b9f04f9cb69bb", null ],
    [ "y", "struct_coord_struct.html#a1a5966a881bc3e76e9becf00639585ac", null ]
];