var annotated_dup =
[
    [ "CoordStruct", "struct_coord_struct.html", "struct_coord_struct" ]
];