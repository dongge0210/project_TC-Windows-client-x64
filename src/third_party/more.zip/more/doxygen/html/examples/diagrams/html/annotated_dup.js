var annotated_dup =
[
    [ "A", "class_a.html", "class_a" ],
    [ "B", "class_b.html", "class_b" ],
    [ "C", "class_c.html", "class_c" ],
    [ "D", "class_d.html", "class_d" ],
    [ "E", "class_e.html", null ]
];