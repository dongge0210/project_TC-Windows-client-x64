var class_b =
[
    [ "m_a", "class_b.html#a26c70b64fe7cf17fcced7755ecff7537", null ]
];