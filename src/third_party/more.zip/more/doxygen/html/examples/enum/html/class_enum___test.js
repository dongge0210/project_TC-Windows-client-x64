var class_enum___test =
[
    [ "AnotherEnum", "class_enum___test.html#a633286511e19b996e97699d7dd2cd2a0", [
      [ "V1", "class_enum___test.html#a633286511e19b996e97699d7dd2cd2a0ab0e5fe049a18d196b564c00bb241722f", null ],
      [ "V2", "class_enum___test.html#a633286511e19b996e97699d7dd2cd2a0ae83b4255ceeedf0c49dd65d1eff8b750", null ]
    ] ],
    [ "TEnum", "class_enum___test.html#a8d096bc026dbb395991f02e3ca86eb1c", [
      [ "Val1", "class_enum___test.html#a8d096bc026dbb395991f02e3ca86eb1cac15a534033ae678fd0d1684a5366467e", null ],
      [ "Val2", "class_enum___test.html#a8d096bc026dbb395991f02e3ca86eb1ca284b56694c3f4513699fc86ea30527b0", null ]
    ] ]
];