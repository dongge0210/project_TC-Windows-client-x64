//
// huge.c
//
//      Copyright (c) Microsoft Corporation. All rights reserved.
//

extern unsigned int const _HUGE[2] = { 0x00000000, 0x7ff00000 };
