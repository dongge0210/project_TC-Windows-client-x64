//
// thread_locale.cpp
//
//      Copyright (c) Microsoft Corporation. All rights reserved.
//
#include <vcruntime.h>



extern "C" int __CRTDECL _get_startup_thread_locale_mode()
{
    return 0;
}
