//
// fltused.cpp
//
//      Copyright (c) Microsoft Corporation. All rights reserved.
//
// Default definition of _fltused.
//

extern "C" int _fltused{0x9875};
