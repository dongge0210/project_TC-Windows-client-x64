//
// std_nothrow.cpp
//
//      Copyright (c) Microsoft Corporation. All rights reserved.
//
// Defines std::nothrow.
//
#include <vcruntime_internal.h>
#include <vcruntime_new.h>

namespace std
{
    const nothrow_t nothrow;
}
