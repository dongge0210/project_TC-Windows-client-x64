//
// Copyright (C) Microsoft Corporation
// All rights reserved.
//

#include "pch.h"

int __cdecl _main();

int CALLBACK WinMain(_In_ HINSTANCE, _In_opt_ HINSTANCE, _In_ LPSTR, _In_ int)
{
	return _main();
}
