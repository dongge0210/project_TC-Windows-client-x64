//
// Copyright (C) Microsoft Corporation
// All rights reserved.
//

#include "pch.h"

int __cdecl _main();

int __cdecl main()
{
	return _main();
}
