PDCurses common files
=====================

This directory is for files which are platform-specific, yet shared by
more than one platform, in contrast to the "common core" in ../pdcurses.


Distribution Status
-------------------

The files in this directory are released to the public domain.
