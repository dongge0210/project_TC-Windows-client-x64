#include <atlassem.h>

extern "C"
{
	int _forceAtlDllManifest;
}
