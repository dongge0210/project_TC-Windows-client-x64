﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.11.35312.102
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "Project1", "Project1\Project1.vcxproj", "{5004BA94-F9A4-4F6A-9008-5C8B00828505}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{5004BA94-F9A4-4F6A-9008-5C8B00828505}.Debug|x64.ActiveCfg = Debug|x64
		{5004BA94-F9A4-4F6A-9008-5C8B00828505}.Debug|x64.Build.0 = Debug|x64
		{5004BA94-F9A4-4F6A-9008-5C8B00828505}.Debug|x86.ActiveCfg = Debug|Win32
		{5004BA94-F9A4-4F6A-9008-5C8B00828505}.Debug|x86.Build.0 = Debug|Win32
		{5004BA94-F9A4-4F6A-9008-5C8B00828505}.Release|x64.ActiveCfg = Release|x64
		{5004BA94-F9A4-4F6A-9008-5C8B00828505}.Release|x64.Build.0 = Release|x64
		{5004BA94-F9A4-4F6A-9008-5C8B008285