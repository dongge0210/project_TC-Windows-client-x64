{
  "Version": 1,
  "WorkspaceRootPath": "F:\\Win_x64-sysMonitor\\Project-MOnitor-TC\\",
  "Documents": [
    {
      "AbsoluteMoniker": "D:0:0:{042E4CC1-8D48-4B15-8256-A85FCA1F7163}|Project-MOnitor-TC.vcxproj|F:\\Win_x64-sysMonitor\\Project-MOnitor-TC\\Project-MOnitor-TC.cpp||{D0E1A5C6-B359-4E41-9B60-3365922C2A22}",
      "RelativeMoniker": "D:0:0:{042E4CC1-8D48-4B15-8256-A85FCA1F7163}|Project-MOnitor-TC.vcxproj|solutionrelative:Project-MOnitor-TC.cpp||{D0E1A5C6-B359-4E41-9B60-3365922C2A22}"
    }
  ],
  "DocumentGroupContainers": [
    {
      "Orientation": 0,
      "VerticalTabListWidth": 256,
      "DocumentGroups": [
        {
          "DockedWidth": 200,
          "SelectedChildIndex": 5,
          "Children": [
            {
              "$type": "Bookmark",
              "Name": "ST:128:0:{1fc202d4-d401-403c-9834-5b218574bb67}"
            },
            {
              "$type": "Bookmark",
              "Name": "ST:129:0:{1fc202d4-d401-403c-9834-5b218574bb67}"
            },
            {
              "$type": "Bookmark",
           